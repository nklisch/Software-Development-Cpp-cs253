#include "Enemy.h"
#include <cassert>

int main() {
  Enemy e("keys");
  assert(!e);
}
