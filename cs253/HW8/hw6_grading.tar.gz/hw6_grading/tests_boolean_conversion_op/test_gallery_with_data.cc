#include "Gallery.h"
#include <cassert>

int main() {

  Gallery g("keys", "in1");
  assert(g);
}
