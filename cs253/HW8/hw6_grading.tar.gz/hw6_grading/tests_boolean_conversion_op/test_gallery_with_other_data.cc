#include "Gallery.h"
#include <cassert>

int main() {

  Gallery g("keys", "in2", "in3", "in4");
  assert(g);
}
